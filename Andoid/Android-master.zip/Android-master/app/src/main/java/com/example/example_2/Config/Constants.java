package com.example.example_2.Config;

public class Constants {
    public static String BD_NAME= "users";
}
