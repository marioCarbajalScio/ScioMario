# NetCoreAPITemplate
Starter template using .net core
